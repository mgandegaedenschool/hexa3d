<div class="container irmr3-test-container">
    <form action="" method="post">
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Ingénieur mécanicien<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="inge-mecanicien" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="inge-mecanicien" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="inge-mecanicien" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Statisticien<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="statisticien" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="statisticien" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="statisticien" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Chimiste<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="chimiste" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="chimiste" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="chimiste" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Animateur radio/télé<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="animateur-radio" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="animateur-radio" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="animateur-radio" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Dessinateur publicitaire<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="dess-publicitaire" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="dess-publicitaire" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="dess-publicitaire" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Romancier<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="romancier" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="romancier" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="romancier" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Chef d'orchestre<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="ch-orchestre" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="ch-orchestre" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="ch-orchestre" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Psychologue scolaire<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="psychologue-sco" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="psychologue-sco" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="psychologue-sco" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Assistant de direction<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="ass-direction" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="ass-direction" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="ass-direction" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Menuisier<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="menuisier" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="menuisier" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="menuisier" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Chirurgien<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="chirurgien" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="chirurgien" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="chirurgien" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Pépiniériste - arboriculteur<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="pepinieriste-arbo" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="pepinieriste-arbo" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="pepinieriste-arbo" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
    </form>
    <section class="next-previous-container d-flex justify-content-between flex-column flex-md-row flex-lg-row mt-4">
        <div class="d-flex justify-content-center justify-content-md-start justify-content-lg-start align-items-center py-4">
            <a href="#" class="next-btn next-btn-irmr3 d-inline-block mx-4 my-0"><i class="fas fa-question-circle"></i> Besoins d'aide ?</a>
        </div>
        <div class="d-flex justify-content-center justify-content-md-end justify-content-lg-end align-items-center py-4">
            <a href="?step=3&part=1" class="next-btn next-btn-irmr3 d-inline-block mx-4 my-0"><i class='fas fa-chevron-left mr-3'></i> Précédent</a>
            <a href="?step=3&part=3" class="next-btn next-btn-irmr3 d-inline-block mx-4 my-0">Suivant <i class='fas fa-chevron-right ml-3'></i></a>
        </div>
    </section>

</div>