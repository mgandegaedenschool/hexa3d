<div class="container irmr3-test-container">
    <form action="" method="post">
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Agent d'assurance<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="agent-assur" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="agent-assur" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="agent-assur" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Métérologue<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="meterologue" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="meterologue" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="meterologue" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Vendeur<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="vendeur" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="vendeur" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="vendeur" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Dessinateur de bande dessinées<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="dess-bd" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="dess-bd" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="dess-bd" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Auteur d'art dramatique<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="auteur-art-drama" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="auteur-art-drama" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="auteur-art-drama" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Compositeur de musique<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="compositeur-mus" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="compositeur-mus" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="compositeur-mus" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Professeur d'économie sociale et familiale<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="professeur-eco-soc-fam" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="professeur-eco-soc-fam" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="professeur-economie-soc" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Opérateur de saisie de données<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="ope-saisie-donnees" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="ope-saisie-donnees" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="ope-saisie-donnees" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Cordonnier<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="cordonnier" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="cordonnier" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="cordonnier" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Pédiatre<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="pediatre" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="pediatre" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="pediatre" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Jardinier paysagiste<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="jard-paysagiste" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="jard-paysagiste" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="jard-paysagiste" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
        <div class="form-row irmr3-form-row mb-3">
            <div class="p-0 col-12 col-md-6 col-lg-6">
                <p class="job">Technicien de maintenance en informatique<span class="hidden-definition">définition du métier au survol</span></p>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="tech-maintenance-info" value="0">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="tech-maintenance-info" value="1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
            <div class="form-check col-4 col-md-2 col-lg-2 position-relative d-flex justify-content-center align-items-center">
                <input type="radio" class="position-absolute test-radio-input" name="tech-maintenance-info" value="2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-check2 position-absolute" viewBox="0 0 16 16">
                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
                </svg>
            </div>
        </div>
    </form>
    <section class="next-previous-container d-flex justify-content-between flex-column flex-md-row flex-lg-row mt-4">
        <div class="d-flex justify-content-center justify-content-md-start justify-content-lg-start align-items-center py-4">
            <a href="#" class="next-btn next-btn-irmr3 d-inline-block mx-4 my-0"><i class="fas fa-question-circle"></i> Besoins d'aide ?</a>
        </div>
        <div class="d-flex justify-content-center justify-content-md-end justify-content-lg-end align-items-center py-4">
            <a href="?step=3&part=2" class="next-btn next-btn-irmr3 d-inline-block mx-4 my-0"><i class='fas fa-chevron-left mr-3'></i> Précédent</a>
            <a href="?step=3&part=4" class="next-btn next-btn-irmr3 d-inline-block mx-4 my-0">Suivant <i class='fas fa-chevron-right ml-3'></i></a>
        </div>
    </section>
</div>